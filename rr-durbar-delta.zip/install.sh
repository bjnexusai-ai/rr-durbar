#!/usr/bin/env bash
# Run from the RR-Durbar repo root:  bash /tmp/d/install.sh
D="$(cd "$(dirname "$0")" && pwd)"
fail() { echo ""; echo "STOPPED: $1"; echo "Nothing in your repo was changed."; exit 1; }
[ -d .git ] || fail "this is not the repo root (no .git folder)."
[ -d assets ] && [ -d images ] || fail "old assets/ or images/ folder not found here."
rm -rf /tmp/rrsite && mkdir -p /tmp/rrsite/public || fail "cannot make a temp folder."
cp -r assets images /tmp/rrsite/public/ && cp -r "$D/public/." /tmp/rrsite/public/ && cp "$D/wrangler.jsonc" /tmp/rrsite/ || fail "copy failed."
cp "$D/manifest.md5" /tmp/rrsite/public/.manifest.md5
echo "Checking every file of the new site..."
if ! (cd /tmp/rrsite/public && md5sum -c --quiet .manifest.md5); then fail "some files are missing or different (listed above). Your old images may not be the version I expected."; fi
rm /tmp/rrsite/public/.manifest.md5
echo "All files OK. Switching the repo to the new layout..."
rm -rf index.html assets images public wrangler.jsonc
cp -r /tmp/rrsite/public ./public && cp /tmp/rrsite/wrangler.jsonc ./wrangler.jsonc
echo "Done. public/ has $(find public -type f | wc -l) files."
[ "$DRY" = "1" ] && { echo "(dry run: no git, no deploy)"; exit 0; }
git add -A && git commit -q -m "v79d with live Order Now" && git push || fail "git failed (the new files are in place, but not saved to GitHub)."
if [ -z "$CLOUDFLARE_API_TOKEN" ]; then echo "Saved to GitHub. Now set the Cloudflare token and run: npx wrangler deploy"; exit 0; fi
npx wrangler deploy
